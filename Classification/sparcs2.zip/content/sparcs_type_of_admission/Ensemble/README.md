# Summary of Ensemble

[<< Go back](../README.md)


## Ensemble structure
| Model             |   Weight |
|:------------------|---------:|
| 3_Default_Xgboost |        1 |

### Metric details
|           |   Elective |   Emergency |    Newborn |   Not Available |   Trauma |     Urgent |   accuracy |   macro avg |   weighted avg |   logloss |
|:----------|-----------:|------------:|-----------:|----------------:|---------:|-----------:|-----------:|------------:|---------------:|----------:|
| precision |   0.827586 |    0.960155 |   0.995349 |             0.8 |        0 |   0.728346 |   0.923146 |    0.718573 |       0.918319 |  0.214198 |
| recall    |   0.880473 |    0.970075 |   1        |             0.8 |        0 |   0.565749 |   0.923146 |    0.702716 |       0.923146 |  0.214198 |
| f1-score  |   0.853211 |    0.965089 |   0.997669 |             0.8 |        0 |   0.636833 |   0.923146 |    0.7088   |       0.919805 |  0.214198 |
| support   | 845        | 2807        | 428        |             5   |       12 | 327        |   0.923146 | 4424        |    4424        |  0.214198 |


## Confusion matrix
|                          |   Predicted as Elective |   Predicted as Emergency |   Predicted as Newborn |   Predicted as Not Available |   Predicted as Trauma |   Predicted as Urgent |
|:-------------------------|------------------------:|-------------------------:|-----------------------:|-----------------------------:|----------------------:|----------------------:|
| Labeled as Elective      |                     744 |                       58 |                      0 |                            0 |                     0 |                    43 |
| Labeled as Emergency     |                      55 |                     2723 |                      2 |                            1 |                     0 |                    26 |
| Labeled as Newborn       |                       0 |                        0 |                    428 |                            0 |                     0 |                     0 |
| Labeled as Not Available |                       0 |                        1 |                      0 |                            4 |                     0 |                     0 |
| Labeled as Trauma        |                       1 |                       11 |                      0 |                            0 |                     0 |                     0 |
| Labeled as Urgent        |                      99 |                       43 |                      0 |                            0 |                     0 |                   185 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Precision Recall Curve

![Precision Recall Curve](precision_recall_curve.png)



[<< Go back](../README.md)
