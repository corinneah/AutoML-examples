# Summary of 1_Baseline

[<< Go back](../README.md)


## Baseline Regressor (Baseline)
- **n_jobs**: -1
- **explain_level**: 2

## Validation
 - **validation_type**: split
 - **train_ratio**: 0.75
 - **shuffle**: True

## Optimized metric
rmse

## Training time

2.3 seconds

### Metric details:
| Metric   |           Score |
|:---------|----------------:|
| MAE      | 11571.8         |
| MSE      |     5.54191e+08 |
| RMSE     | 23541.3         |
| R2       |    -0.000315626 |
| MAPE     |     5.80507     |



## Learning curves
![Learning curves](learning_curves.png)
## True vs Predicted

![True vs Predicted](true_vs_predicted.png)


## Predicted vs Residuals

![Predicted vs Residuals](predicted_vs_residuals.png)



[<< Go back](../README.md)
