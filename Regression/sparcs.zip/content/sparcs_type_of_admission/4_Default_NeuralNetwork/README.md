# Summary of 4_Default_NeuralNetwork

[<< Go back](../README.md)


## Neural Network
- **n_jobs**: -1
- **dense_1_size**: 32
- **dense_2_size**: 16
- **learning_rate**: 0.05
- **num_class**: 6
- **explain_level**: 2

## Validation
 - **validation_type**: split
 - **train_ratio**: 0.75
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
logloss

## Training time

8.4 seconds

### Metric details
|           |   Elective |   Emergency |    Newborn |   Not Available |   Trauma |     Urgent |   accuracy |   macro avg |   weighted avg |   logloss |
|:----------|-----------:|------------:|-----------:|----------------:|---------:|-----------:|-----------:|------------:|---------------:|----------:|
| precision |   0.721264 |    0.938904 |   0.981567 |               0 |        0 |   0.438776 |   0.880651 |    0.513419 |       0.860887 |  0.358817 |
| recall    |   0.891124 |    0.952618 |   0.995327 |               0 |        0 |   0.131498 |   0.880651 |    0.495095 |       0.880651 |  0.358817 |
| f1-score  |   0.797247 |    0.945712 |   0.988399 |               0 |        0 |   0.202353 |   0.880651 |    0.488952 |       0.862905 |  0.358817 |
| support   | 845        | 2807        | 428        |               5 |       12 | 327        |   0.880651 | 4424        |    4424        |  0.358817 |


## Confusion matrix
|                          |   Predicted as Elective |   Predicted as Emergency |   Predicted as Newborn |   Predicted as Not Available |   Predicted as Trauma |   Predicted as Urgent |
|:-------------------------|------------------------:|-------------------------:|-----------------------:|-----------------------------:|----------------------:|----------------------:|
| Labeled as Elective      |                     753 |                       65 |                      2 |                            0 |                     0 |                    25 |
| Labeled as Emergency     |                     103 |                     2674 |                      2 |                            0 |                     0 |                    28 |
| Labeled as Newborn       |                       0 |                        0 |                    426 |                            0 |                     0 |                     2 |
| Labeled as Not Available |                       0 |                        5 |                      0 |                            0 |                     0 |                     0 |
| Labeled as Trauma        |                       2 |                       10 |                      0 |                            0 |                     0 |                     0 |
| Labeled as Urgent        |                     186 |                       94 |                      4 |                            0 |                     0 |                    43 |

## Learning curves
![Learning curves](learning_curves.png)

## Permutation-based Importance
![Permutation-based Importance](permutation_importance.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Precision Recall Curve

![Precision Recall Curve](precision_recall_curve.png)



[<< Go back](../README.md)
